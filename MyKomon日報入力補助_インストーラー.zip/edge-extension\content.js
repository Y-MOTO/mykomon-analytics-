// content.js
// MyKomonの日報入力画面にフローティングUIを表示する

(function () {
  var floatingUI = null;
  var triggerBtn = null;
  var isUIVisible = false;
  var initialized = false;

  var state = {
    category: null,
    status: null,
    blocking: []
  };

  function init() {
    if (initialized) return;
    var mceContainer = document.querySelector('.mce-container');
    if (!mceContainer) return;

    initialized = true;
    injectStyles();
    createTriggerButton(mceContainer);
    createFloatingUI();
  }

  function createTriggerButton(mceContainer) {
    triggerBtn = document.createElement('button');
    triggerBtn.id = 'mkh-trigger';
    triggerBtn.type = 'button';
    triggerBtn.textContent = '日報補助';
    triggerBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      e.preventDefault();
      if (isUIVisible) {
        hideUI();
      } else {
        showUI();
      }
    });

    // エディタの右端に絶対配置
    var rect = mceContainer.getBoundingClientRect();
    var scrollTop = window.scrollY || document.documentElement.scrollTop;
    var scrollLeft = window.scrollX || document.documentElement.scrollLeft;
    triggerBtn.style.position = 'absolute';
    triggerBtn.style.top = (rect.top + scrollTop + 4) + 'px';
    triggerBtn.style.left = (rect.right + scrollLeft + 4) + 'px';
    triggerBtn.style.zIndex = '999998';
    document.body.appendChild(triggerBtn);
  }

  function createFloatingUI() {
    floatingUI = document.createElement('div');
    floatingUI.id = 'mykomon-helper';

    var html = '<div id="mkh-header">MyKomon 日報入力補助</div>';

    html += '<div class="mkh-card">';
    html += '<div class="mkh-card-title">[1] 業務区分</div>';
    html += '<div class="mkh-options" id="mkh-category">';
    html += '<button type="button" class="mkh-btn" data-value="申告">申告</button>';
    html += '<button type="button" class="mkh-btn" data-value="相談">相談</button>';
    html += '<button type="button" class="mkh-btn" data-value="監査">監査</button>';
    html += '<button type="button" class="mkh-btn" data-value="記帳代行">記帳代行</button>';
    html += '<button type="button" class="mkh-btn" data-value="その他">その他</button>';
    html += '</div></div>';

    html += '<div class="mkh-card">';
    html += '<div class="mkh-card-title">[2] 業務ステータス</div>';
    html += '<div class="mkh-options" id="mkh-status">';
    html += '<button type="button" class="mkh-btn" data-value="完了">完了</button>';
    html += '<button type="button" class="mkh-btn" data-value="継続">継続</button>';
    html += '<button type="button" class="mkh-btn" data-value="中断">中断</button>';
    html += '</div></div>';

    html += '<div class="mkh-card" id="mkh-blocking-card" style="display:none">';
    html += '<div class="mkh-card-title">[3] 阻害要因（複数選択可）</div>';
    html += '<div class="mkh-options" id="mkh-blocking">';
    html += '<button type="button" class="mkh-btn" data-value="資料待ち">資料待ち</button>';
    html += '<button type="button" class="mkh-btn" data-value="確認中">確認中</button>';
    html += '<button type="button" class="mkh-btn" data-value="知識不足">知識不足</button>';
    html += '<button type="button" class="mkh-btn" data-value="客先都合">客先都合</button>';
    html += '<button type="button" class="mkh-btn" data-value="その他">その他</button>';
    html += '</div></div>';

    html += '<div id="mkh-message"></div>';
    html += '<div id="mkh-success"></div>';
    html += '<button type="button" id="mkh-insert-btn">平文に反映する</button>';

    floatingUI.innerHTML = html;
    floatingUI.style.display = 'none';
    document.body.appendChild(floatingUI);
    setupCardEvents();
  }

  function showUI() {
    resetState();
    var rect = triggerBtn.getBoundingClientRect();
    var scrollTop = window.scrollY || document.documentElement.scrollTop;
    var scrollLeft = window.scrollX || document.documentElement.scrollLeft;
    floatingUI.style.top = (rect.bottom + scrollTop + 4) + 'px';
    floatingUI.style.left = (rect.left + scrollLeft) + 'px';
    floatingUI.style.display = 'block';
    isUIVisible = true;
    triggerBtn.classList.add('mkh-active');
  }

  function hideUI() {
    floatingUI.style.display = 'none';
    isUIVisible = false;
    triggerBtn.classList.remove('mkh-active');
  }

  function resetState() {
    state.category = null;
    state.status = null;
    state.blocking = [];
    var btns = floatingUI.querySelectorAll('.mkh-btn');
    for (var i = 0; i < btns.length; i++) btns[i].classList.remove('mkh-selected');
    document.getElementById('mkh-blocking-card').style.display = 'none';
    document.getElementById('mkh-message').textContent = '';
    document.getElementById('mkh-success').textContent = '';
  }

  function setupCardEvents() {
    document.getElementById('mkh-category').addEventListener('click', function(e) {
      var btn = e.target.closest('.mkh-btn');
      if (!btn) return;
      toggleSingle('mkh-category', 'category', btn);
      clearMessage();
    });

    document.getElementById('mkh-status').addEventListener('click', function(e) {
      var btn = e.target.closest('.mkh-btn');
      if (!btn) return;
      toggleSingle('mkh-status', 'status', btn);
      updateBlockingVisibility();
      clearMessage();
    });

    document.getElementById('mkh-blocking').addEventListener('click', function(e) {
      var btn = e.target.closest('.mkh-btn');
      if (!btn) return;
      toggleMulti(btn);
      clearMessage();
    });

    document.getElementById('mkh-insert-btn').addEventListener('click', function() {
      if (!state.category) { showMessage('業務区分を選択してください'); return; }
      if (!state.status) { showMessage('業務ステータスを選択してください'); return; }
      var tag = buildTag();
      var ok = insertTag(tag);
      if (ok) {
        document.getElementById('mkh-success').textContent = '反映しました';
        setTimeout(hideUI, 800);
      } else {
        showMessage('挿入に失敗しました。ページを再読み込みしてください。');
      }
    });
  }

  function toggleSingle(containerId, stateKey, btn) {
    var container = document.getElementById(containerId);
    if (state[stateKey] === btn.dataset.value) {
      state[stateKey] = null;
      btn.classList.remove('mkh-selected');
    } else {
      var btns = container.querySelectorAll('.mkh-btn');
      for (var i = 0; i < btns.length; i++) btns[i].classList.remove('mkh-selected');
      state[stateKey] = btn.dataset.value;
      btn.classList.add('mkh-selected');
    }
  }

  function toggleMulti(btn) {
    var value = btn.dataset.value;
    var index = state.blocking.indexOf(value);
    if (index === -1) {
      state.blocking.push(value);
      btn.classList.add('mkh-selected');
    } else {
      state.blocking.splice(index, 1);
      btn.classList.remove('mkh-selected');
    }
  }

  function updateBlockingVisibility() {
    var card = document.getElementById('mkh-blocking-card');
    var show = state.status === '継続' || state.status === '中断';
    card.style.display = show ? 'block' : 'none';
    if (!show) {
      state.blocking = [];
      var btns = document.querySelectorAll('#mkh-blocking .mkh-btn');
      for (var i = 0; i < btns.length; i++) btns[i].classList.remove('mkh-selected');
    }
  }

  function buildTag() {
    var blockingText = state.blocking.length > 0 ? state.blocking.join('・') : null;
    var blockingHashtags = state.blocking.map(function(v) { return '#阻害要因_' + v; }).join(' ');
    var tag = '\n---\n';
    tag += '【業務区分】' + state.category + '\n';
    tag += '【ステータス】' + state.status + '\n';
    if (blockingText) tag += '【阻害要因】' + blockingText + '\n';
    tag += '#業務区分_' + state.category + ' #ステータス_' + state.status;
    if (blockingHashtags) tag += ' ' + blockingHashtags;
    return tag;
  }

  function insertTag(tag) {
    var htmlTag = tag.replace(/\n/g, '<br>');
    if (typeof tinymce !== 'undefined') {
      var editor = tinymce.get('inc_editor') || tinymce.activeEditor;
      if (editor) {
        editor.execCommand('mceInsertContent', false, htmlTag);
        return true;
      }
    }
    var ta = document.querySelector('textarea#inc_editor')
      || document.querySelector('textarea[name="schedule.workText"]');
    if (ta) {
      ta.value += tag;
      ta.dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    }
    return false;
  }

  function showMessage(msg) {
    document.getElementById('mkh-message').textContent = msg;
  }

  function clearMessage() {
    document.getElementById('mkh-message').textContent = '';
    document.getElementById('mkh-success').textContent = '';
  }

  document.addEventListener('click', function(e) {
    if (!isUIVisible) return;
    if (floatingUI && floatingUI.contains(e.target)) return;
    if (triggerBtn && triggerBtn.contains(e.target)) return;
    hideUI();
  });

  function injectStyles() {
    var style = document.createElement('style');
    style.textContent = [
      '#mkh-trigger {',
      '  margin-top: 6px; padding: 5px 14px;',
      '  background: #1a56a0; color: white;',
      '  border: none; border-radius: 4px;',
      '  font-size: 12px; cursor: pointer;',
      '  font-family: Meiryo, sans-serif; display: inline-block;',
      '}',
      '#mkh-trigger:hover, #mkh-trigger.mkh-active { background: #154a8a; }',
      '#mykomon-helper {',
      '  position: absolute; z-index: 999999;',
      '  background: #f5f7fa; border: 1px solid #c0cfe0;',
      '  border-radius: 8px; box-shadow: 0 4px 16px rgba(0,0,0,0.18);',
      '  width: 340px; font-family: Meiryo, sans-serif;',
      '  font-size: 13px; color: #333;',
      '}',
      '#mkh-header {',
      '  background: #1a56a0; color: white;',
      '  padding: 10px 14px; font-size: 13px; font-weight: bold;',
      '  border-radius: 8px 8px 0 0;',
      '}',
      '#mykomon-helper .mkh-card {',
      '  background: white; margin: 10px;',
      '  border-radius: 6px; padding: 12px;',
      '  box-shadow: 0 1px 3px rgba(0,0,0,0.08);',
      '}',
      '#mykomon-helper .mkh-card-title {',
      '  font-weight: bold; margin-bottom: 8px;',
      '  color: #1a56a0; font-size: 11px;',
      '}',
      '#mykomon-helper .mkh-options { display: flex; flex-wrap: wrap; gap: 6px; }',
      '#mykomon-helper .mkh-btn {',
      '  padding: 5px 11px; border: 1.5px solid #ccc;',
      '  border-radius: 20px; background: white; cursor: pointer;',
      '  font-size: 12px; font-family: Meiryo, sans-serif;',
      '}',
      '#mykomon-helper .mkh-btn:hover { border-color: #1a56a0; color: #1a56a0; }',
      '#mykomon-helper .mkh-btn.mkh-selected {',
      '  background: #1a56a0; border-color: #1a56a0; color: white;',
      '}',
      '#mkh-message { text-align: center; font-size: 11px; color: #e74c3c; margin: -4px 10px 4px; min-height: 14px; }',
      '#mkh-success { text-align: center; font-size: 11px; color: #27ae60; margin: -4px 10px 4px; min-height: 14px; }',
      '#mkh-insert-btn {',
      '  display: block; width: calc(100% - 20px);',
      '  margin: 0 10px 12px; padding: 10px;',
      '  background: #1a56a0; color: white; border: none;',
      '  border-radius: 6px; font-size: 13px; font-weight: bold;',
      '  cursor: pointer; font-family: Meiryo, sans-serif;',
      '}',
      '#mkh-insert-btn:hover { background: #154a8a; }'
    ].join('\n');
    document.head.appendChild(style);
  }

  var checkCount = 0;
  var waitInterval = setInterval(function() {
    checkCount++;
    if (initialized || checkCount > 40) {
      clearInterval(waitInterval);
      return;
    }
    init();
  }, 500);

})();
